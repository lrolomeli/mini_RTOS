var rtos__main_8c =
[
    [ "dummy_task1", "rtos__main_8c.html#aaee1153f423af33ef273c0a8046480ac", null ],
    [ "dummy_task2", "rtos__main_8c.html#a2db4a9cc129f09eb3b63a2f902b3bf79", null ],
    [ "dummy_task3", "rtos__main_8c.html#a0851438d42bae396442560c8572658ff", null ],
    [ "init_operating_system", "rtos__main_8c.html#ad6a51a859917f0937343d970e6cd81b4", null ],
    [ "main", "rtos__main_8c.html#a840291bc02cba5474a4cb46a9b9566fe", null ]
];