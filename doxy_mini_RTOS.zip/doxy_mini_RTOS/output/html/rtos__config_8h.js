var rtos__config_8h =
[
    [ "RTOS_ENABLE_IS_ALIVE", "rtos__config_8h.html#a39f0bdba655835bed09acf2b877dda7d", null ],
    [ "RTOS_IS_ALIVE_PERIOD_IN_US", "rtos__config_8h.html#af96730a20bdd5d445fc10cd8a714f6f0", null ],
    [ "RTOS_IS_ALIVE_PIN", "rtos__config_8h.html#a99b12db21253b934c642dbb7d63415c2", null ],
    [ "RTOS_IS_ALIVE_PORT", "rtos__config_8h.html#a734f36ab1e490fdcaabf1921abee6716", null ],
    [ "RTOS_MAX_NUMBER_OF_TASKS", "rtos__config_8h.html#afab84c04df2c86443de30e78f61ba0e6", null ],
    [ "RTOS_STACK_SIZE", "rtos__config_8h.html#a0d8b036199750366136ec44cc68eeeec", null ],
    [ "RTOS_TIC_PERIOD_IN_US", "rtos__config_8h.html#aacfc3b96c15dfcdda284a1acfacafd92", null ]
];