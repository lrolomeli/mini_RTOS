var searchData=
[
  ['current_5ftask',['current_task',['../structtask__list__t.html#a0795df647543777eef5ec8c4a7add616',1,'task_list_t']]]
];
