var searchData=
[
  ['local_5ftick',['local_tick',['../structrtos__tcb__t.html#a56c6de13ab1f90d8f13323ab06d31405',1,'rtos_tcb_t']]]
];
