var searchData=
[
  ['task_5fpriority_5ftype_5fe',['task_priority_type_e',['../rtos_8h.html#aa7b196491370e7a2e5c031dbe25056de',1,'rtos.h']]],
  ['task_5fstate_5fe',['task_state_e',['../rtos_8h.html#a6924eb4ed00ed119294b1f2d81a8d7dd',1,'rtos.h']]],
  ['task_5fswitch_5ftype_5fe',['task_switch_type_e',['../rtos_8h.html#aa5e10f864591edf2caca6690fbea63f5',1,'rtos.h']]]
];
