var searchData=
[
  ['next_5ftask',['next_task',['../structtask__list__t.html#a5e3e14174c6af2b18f3f76e84f662724',1,'task_list_t']]],
  ['ntasks',['nTasks',['../structtask__list__t.html#a5de738e08c563b27879093ae33053bb7',1,'task_list_t']]]
];
