var searchData=
[
  ['refresh_5fis_5falive',['refresh_is_alive',['../rtos_8c.html#ae25772d4efa4a8bc45435fde080f1db1',1,'rtos.c']]],
  ['reload_5fsystick',['reload_systick',['../rtos_8c.html#a1ceb3400b8198a46a5d1a4eac152c3dc',1,'rtos.c']]],
  ['rtos_5factivate_5ftask',['rtos_activate_task',['../rtos_8c.html#a1e438279e41f08e401c4cbf7bd7e3080',1,'rtos_activate_task(rtos_task_handle_t task):&#160;rtos.c'],['../rtos_8h.html#a1e438279e41f08e401c4cbf7bd7e3080',1,'rtos_activate_task(rtos_task_handle_t task):&#160;rtos.c']]],
  ['rtos_5fcreate_5ftask',['rtos_create_task',['../rtos_8c.html#a9b85523da77622a323eb372876dfc751',1,'rtos_create_task(void(*task_body)(), uint8_t priority, rtos_autostart_e autostart):&#160;rtos.c'],['../rtos_8h.html#a9b85523da77622a323eb372876dfc751',1,'rtos_create_task(void(*task_body)(), uint8_t priority, rtos_autostart_e autostart):&#160;rtos.c']]],
  ['rtos_5fdelay',['rtos_delay',['../rtos_8c.html#ab057ccfcb6b57d8a5c74698954424a3c',1,'rtos_delay(rtos_tick_t ticks):&#160;rtos.c'],['../rtos_8h.html#ab057ccfcb6b57d8a5c74698954424a3c',1,'rtos_delay(rtos_tick_t ticks):&#160;rtos.c']]],
  ['rtos_5fget_5fclock',['rtos_get_clock',['../rtos_8c.html#acbd74d71425a80d6c94d4f6db9ed6208',1,'rtos_get_clock(void):&#160;rtos.c'],['../rtos_8h.html#acbd74d71425a80d6c94d4f6db9ed6208',1,'rtos_get_clock(void):&#160;rtos.c']]],
  ['rtos_5fstart_5fscheduler',['rtos_start_scheduler',['../rtos_8c.html#ac343e700239fe05a50f3b107a185d737',1,'rtos_start_scheduler(void):&#160;rtos.c'],['../rtos_8h.html#ac343e700239fe05a50f3b107a185d737',1,'rtos_start_scheduler(void):&#160;rtos.c']]],
  ['rtos_5fsuspend_5ftask',['rtos_suspend_task',['../rtos_8c.html#aea0dd80ed0f0129c49dc95863f43c5dc',1,'rtos_suspend_task(void):&#160;rtos.c'],['../rtos_8h.html#aea0dd80ed0f0129c49dc95863f43c5dc',1,'rtos_suspend_task(void):&#160;rtos.c']]]
];
