var searchData=
[
  ['reserved_5fmemory',['RESERVED_MEMORY',['../rtos_8h.html#ab6f6523166d797b5b53efc5b6c49be1c',1,'rtos.h']]],
  ['rtos_5fenable_5fis_5falive',['RTOS_ENABLE_IS_ALIVE',['../rtos__config_8h.html#a39f0bdba655835bed09acf2b877dda7d',1,'rtos_config.h']]],
  ['rtos_5finvalid_5ftask',['RTOS_INVALID_TASK',['../rtos_8h.html#aa9d5b836fd119d6113293879a6f20f02',1,'rtos.h']]],
  ['rtos_5fis_5falive_5fperiod_5fin_5fus',['RTOS_IS_ALIVE_PERIOD_IN_US',['../rtos__config_8h.html#af96730a20bdd5d445fc10cd8a714f6f0',1,'rtos_config.h']]],
  ['rtos_5fis_5falive_5fpin',['RTOS_IS_ALIVE_PIN',['../rtos__config_8h.html#a99b12db21253b934c642dbb7d63415c2',1,'rtos_config.h']]],
  ['rtos_5fis_5falive_5fport',['RTOS_IS_ALIVE_PORT',['../rtos__config_8h.html#a734f36ab1e490fdcaabf1921abee6716',1,'rtos_config.h']]],
  ['rtos_5fmax_5fnumber_5fof_5ftasks',['RTOS_MAX_NUMBER_OF_TASKS',['../rtos__config_8h.html#afab84c04df2c86443de30e78f61ba0e6',1,'rtos_config.h']]],
  ['rtos_5fstack_5fsize',['RTOS_STACK_SIZE',['../rtos__config_8h.html#a0d8b036199750366136ec44cc68eeeec',1,'rtos_config.h']]],
  ['rtos_5ftic_5fperiod_5fin_5fus',['RTOS_TIC_PERIOD_IN_US',['../rtos__config_8h.html#aacfc3b96c15dfcdda284a1acfacafd92',1,'rtos_config.h']]]
];
