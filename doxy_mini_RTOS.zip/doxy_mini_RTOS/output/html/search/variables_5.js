var searchData=
[
  ['reserved',['reserved',['../structrtos__tcb__t.html#a32055d7f3f63b99d541f45eb4996a9b8',1,'rtos_tcb_t']]]
];
