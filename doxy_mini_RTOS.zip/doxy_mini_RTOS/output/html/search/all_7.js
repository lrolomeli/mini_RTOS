var searchData=
[
  ['idle_5ftask',['idle_task',['../rtos_8c.html#aba04d49a0ff5bf5f2f345018999838cf',1,'rtos.c']]],
  ['init_5fis_5falive',['init_is_alive',['../rtos_8c.html#a3da6087b2f86fb0fb3e76625949e8f5c',1,'rtos.c']]],
  ['init_5foperating_5fsystem',['init_operating_system',['../rtos__main_8c.html#ad6a51a859917f0937343d970e6cd81b4',1,'rtos_main.c']]]
];
