var searchData=
[
  ['global_5ftick',['global_tick',['../structtask__list__t.html#a738b802a3f96664c7fef4b537dcc77fd',1,'task_list_t']]]
];
