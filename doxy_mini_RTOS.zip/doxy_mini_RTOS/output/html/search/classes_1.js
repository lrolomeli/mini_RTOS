var searchData=
[
  ['task_5flist_5ft',['task_list_t',['../structtask__list__t.html',1,'']]]
];
