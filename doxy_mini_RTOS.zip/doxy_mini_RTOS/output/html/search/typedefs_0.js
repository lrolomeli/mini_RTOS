var searchData=
[
  ['rtos_5ftask_5fhandle_5ft',['rtos_task_handle_t',['../rtos_8h.html#a0882c12198dee2bba66fa81918cda67a',1,'rtos.h']]],
  ['rtos_5ftick_5ft',['rtos_tick_t',['../rtos_8h.html#aa2a9532cbb5237b8d4d168255fd7dc8e',1,'rtos.h']]]
];
