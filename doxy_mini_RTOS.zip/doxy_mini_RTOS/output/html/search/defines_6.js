var searchData=
[
  ['task_5fidle',['TASK_IDLE',['../rtos_8h.html#aa56ba1aed5aa073e789fd485da6202f0',1,'rtos.h']]]
];
