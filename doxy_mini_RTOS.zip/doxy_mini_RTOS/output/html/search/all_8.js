var searchData=
[
  ['kautostart',['kAutoStart',['../rtos_8h.html#abc615bb86d706d530b5c2df8fdbb4ed7a478ba0c03215376f5b803b95b0d8a3c9',1,'rtos.h']]],
  ['kfromisr',['kFromISR',['../rtos_8h.html#aa5e10f864591edf2caca6690fbea63f5a9bf49a1ca373b4cb5e2f33cf14adfe18',1,'rtos.h']]],
  ['kfromnormalexec',['kFromNormalExec',['../rtos_8h.html#aa5e10f864591edf2caca6690fbea63f5aed28ca79fb860600c4b833f4a4aeac88',1,'rtos.h']]],
  ['kstartsuspended',['kStartSuspended',['../rtos_8h.html#abc615bb86d706d530b5c2df8fdbb4ed7a02dd13c111098bf63d88903748d7fc97',1,'rtos.h']]]
];
