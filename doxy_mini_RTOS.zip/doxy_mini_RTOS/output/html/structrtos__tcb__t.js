var structrtos__tcb__t =
[
    [ "local_tick", "structrtos__tcb__t.html#a56c6de13ab1f90d8f13323ab06d31405", null ],
    [ "priority", "structrtos__tcb__t.html#a0ad043071ccc7a261d79a759dc9c6f0c", null ],
    [ "reserved", "structrtos__tcb__t.html#a32055d7f3f63b99d541f45eb4996a9b8", null ],
    [ "sp", "structrtos__tcb__t.html#a80a5f386a0f7e3ce5babe362e78ac70e", null ],
    [ "stack", "structrtos__tcb__t.html#ae9e2781393ca0c77dc79e95934538661", null ],
    [ "state", "structrtos__tcb__t.html#a6d2a6834297697f5ce4ac838a6044a26", null ],
    [ "task_body", "structrtos__tcb__t.html#ab28b36bf4a2b76e8039441c43592a074", null ]
];