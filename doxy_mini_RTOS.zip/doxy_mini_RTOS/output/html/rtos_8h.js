var rtos_8h =
[
    [ "rtos_tcb_t", "structrtos__tcb__t.html", "structrtos__tcb__t" ],
    [ "task_list_t", "structtask__list__t.html", "structtask__list__t" ],
    [ "ALL_TASKS_CREATED_CORRECTLY", "rtos_8h.html#a423ae5f980693fe9d6a34d1daf070d1d", null ],
    [ "END_OF_STACK", "rtos_8h.html#ab40875a98a2f99809853d1b6a7a43ef4", null ],
    [ "FORCE_INLINE", "rtos_8h.html#ac032d233a8ebfcd82fd49d0824eefb18", null ],
    [ "RESERVED_MEMORY", "rtos_8h.html#ab6f6523166d797b5b53efc5b6c49be1c", null ],
    [ "RTOS_INVALID_TASK", "rtos_8h.html#aa9d5b836fd119d6113293879a6f20f02", null ],
    [ "STACK_FRAME_SIZE", "rtos_8h.html#a61c1c1d98788a1aad543d1922f343acd", null ],
    [ "STACK_OFFSET_ISR_AND_EXEC", "rtos_8h.html#afdc5a469d18ca028aad77405c2b8c9c5", null ],
    [ "STACK_PC_OFFSET", "rtos_8h.html#acf59d01a322b59c03c7f1bad35dd2550", null ],
    [ "STACK_PSR_DEFAULT", "rtos_8h.html#acdc94897e407b3a96cdc72c435c33d0b", null ],
    [ "STACK_PSR_OFFSET", "rtos_8h.html#ae4922f131f9e3d9b542ede8caceb5569", null ],
    [ "TASK_IDLE", "rtos_8h.html#aa56ba1aed5aa073e789fd485da6202f0", null ],
    [ "VALUE_START_PERIOD", "rtos_8h.html#ab1e47ad629c9ea3a4aa4e5b272fbcfb0", null ],
    [ "rtos_task_handle_t", "rtos_8h.html#a0882c12198dee2bba66fa81918cda67a", null ],
    [ "rtos_tick_t", "rtos_8h.html#aa2a9532cbb5237b8d4d168255fd7dc8e", null ],
    [ "led_state_type_e", "rtos_8h.html#a49b0c80b06b318c4490d245b73e79bb0", [
      [ "ON", "rtos_8h.html#a49b0c80b06b318c4490d245b73e79bb0a977d478dacaae531f95695750d1e9d03", null ],
      [ "OFF", "rtos_8h.html#a49b0c80b06b318c4490d245b73e79bb0aac132f2982b98bcaa3445e535a03ff75", null ]
    ] ],
    [ "rtos_autostart_e", "rtos_8h.html#abc615bb86d706d530b5c2df8fdbb4ed7", [
      [ "kAutoStart", "rtos_8h.html#abc615bb86d706d530b5c2df8fdbb4ed7a478ba0c03215376f5b803b95b0d8a3c9", null ],
      [ "kStartSuspended", "rtos_8h.html#abc615bb86d706d530b5c2df8fdbb4ed7a02dd13c111098bf63d88903748d7fc97", null ]
    ] ],
    [ "start_values_type_e", "rtos_8h.html#ae9a8b759c23a7b03d0755f54bffe1655", [
      [ "START_ZERO", "rtos_8h.html#ae9a8b759c23a7b03d0755f54bffe1655a11952faf560daa96970f0a3206d30a74", null ],
      [ "START_ONE", "rtos_8h.html#ae9a8b759c23a7b03d0755f54bffe1655a92dec00373c91ad7143e7088ac7e5b53", null ]
    ] ],
    [ "task_priority_type_e", "rtos_8h.html#aa7b196491370e7a2e5c031dbe25056de", [
      [ "LOWEST_PRIORITY", "rtos_8h.html#aa7b196491370e7a2e5c031dbe25056dea792e51f8ee001927b2ab1fc0146e0d9c", null ],
      [ "PRIORITY0", "rtos_8h.html#aa7b196491370e7a2e5c031dbe25056dea55aa9647db6bce7a16151df6c8bede70", null ],
      [ "PRIORITY1", "rtos_8h.html#aa7b196491370e7a2e5c031dbe25056dea2e2fd8cd1d710628c77ea142cfc623c3", null ],
      [ "PRIORITY2", "rtos_8h.html#aa7b196491370e7a2e5c031dbe25056dea7bb7524e6f3b2d2028d9b247d5192b3a", null ]
    ] ],
    [ "task_state_e", "rtos_8h.html#a6924eb4ed00ed119294b1f2d81a8d7dd", [
      [ "S_READY", "rtos_8h.html#a6924eb4ed00ed119294b1f2d81a8d7dda5c04dd6713c762cdcc01cc63a66ddbc2", null ],
      [ "S_RUNNING", "rtos_8h.html#a6924eb4ed00ed119294b1f2d81a8d7ddae146e9d79f340ef6356a97ee27015d05", null ],
      [ "S_WAITING", "rtos_8h.html#a6924eb4ed00ed119294b1f2d81a8d7ddaac2df35f0a0dccd7039ec84631fa0a6a", null ],
      [ "S_SUSPENDED", "rtos_8h.html#a6924eb4ed00ed119294b1f2d81a8d7ddaed282b64d6e26f9c658ae966bff4440b", null ]
    ] ],
    [ "task_switch_type_e", "rtos_8h.html#aa5e10f864591edf2caca6690fbea63f5", [
      [ "kFromISR", "rtos_8h.html#aa5e10f864591edf2caca6690fbea63f5a9bf49a1ca373b4cb5e2f33cf14adfe18", null ],
      [ "kFromNormalExec", "rtos_8h.html#aa5e10f864591edf2caca6690fbea63f5aed28ca79fb860600c4b833f4a4aeac88", null ]
    ] ],
    [ "rtos_activate_task", "rtos_8h.html#a1e438279e41f08e401c4cbf7bd7e3080", null ],
    [ "rtos_create_task", "rtos_8h.html#a9b85523da77622a323eb372876dfc751", null ],
    [ "rtos_delay", "rtos_8h.html#ab057ccfcb6b57d8a5c74698954424a3c", null ],
    [ "rtos_get_clock", "rtos_8h.html#acbd74d71425a80d6c94d4f6db9ed6208", null ],
    [ "rtos_start_scheduler", "rtos_8h.html#ac343e700239fe05a50f3b107a185d737", null ],
    [ "rtos_suspend_task", "rtos_8h.html#aea0dd80ed0f0129c49dc95863f43c5dc", null ]
];