var structtask__list__t =
[
    [ "current_task", "structtask__list__t.html#a0795df647543777eef5ec8c4a7add616", null ],
    [ "global_tick", "structtask__list__t.html#a738b802a3f96664c7fef4b537dcc77fd", null ],
    [ "next_task", "structtask__list__t.html#a5e3e14174c6af2b18f3f76e84f662724", null ],
    [ "nTasks", "structtask__list__t.html#a5de738e08c563b27879093ae33053bb7", null ],
    [ "tasks", "structtask__list__t.html#aa8f1ef62eea9a822a7459fe974f73bd2", null ]
];