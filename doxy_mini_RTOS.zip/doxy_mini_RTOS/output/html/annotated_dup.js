var annotated_dup =
[
    [ "rtos_tcb_t", "structrtos__tcb__t.html", "structrtos__tcb__t" ],
    [ "task_list_t", "structtask__list__t.html", "structtask__list__t" ]
];